# Layernaut Studio - Exported Training Pipeline
# Generated: 2026-08-27T03:24:50.133Z

import os, random
import numpy as np

def set_seed(seed=42):
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
    except Exception:
        pass

set_seed(42)

import tensorflow as tf

# ============================
# ENVIRONMENT RECORD
# ============================
# Seeding constrains but does not eliminate variation (see ENVIRONMENT.md), so
# the run records the environment it actually executed in.
def _write_environment_lock(path="environment_lock.txt"):
    import platform, sys
    lines = [f"python: {sys.version.split()[0]} ({platform.platform()})"]
    from importlib.metadata import version, PackageNotFoundError
    # A distribution may be installed under any of several names
    # (tensorflow / tensorflow-cpu / tensorflow-macos), so try each, then fall
    # back to the imported module's own __version__.
    for module, dists in (("tensorflow", ("tensorflow", "tensorflow-cpu", "tensorflow-macos", "tensorflow-gpu")),
                          ("numpy", ("numpy",)),
                          ("sklearn", ("scikit-learn",)),
                          ("xgboost", ("xgboost",))):
        found = None
        for dist in dists:
            try:
                found = version(dist)
                break
            except PackageNotFoundError:
                continue
        if found is None:
            try:
                found = __import__(module).__version__
            except Exception:
                found = "not installed"
        lines.append(f"{module}: {found}")
    try:
        import tensorflow as _tf
        lines.append(f"devices: {[d.name for d in _tf.config.list_physical_devices()]}")
    except Exception:
        pass
    with open(path, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    print("Environment recorded in", path)

_write_environment_lock()

# ============================
# DATA (EDIT DATA_DIR)
# ============================
# Expected folder structure:
#   DATA_DIR/class_a/... , DATA_DIR/class_b/... , ...
DATA_DIR = "path/to/your/image_dataset"
IMG_SIZE = (299, 299)
BATCH_SIZE = 32
EPOCHS = 50

train_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR, validation_split=0.2, subset="training", seed=42,
    image_size=IMG_SIZE, batch_size=BATCH_SIZE, label_mode="categorical",
)
val_ds = tf.keras.utils.image_dataset_from_directory(
    DATA_DIR, validation_split=0.2, subset="validation", seed=42,
    image_size=IMG_SIZE, batch_size=BATCH_SIZE, label_mode="categorical",
)

AUTOTUNE = tf.data.AUTOTUNE
train_ds = train_ds.cache().prefetch(buffer_size=AUTOTUNE)
val_ds = val_ds.cache().prefetch(buffer_size=AUTOTUNE)

import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.applications import InceptionV3

from tensorflow.keras.applications.inception_v3 import preprocess_input

# Load pretrained InceptionV3 model
base_model = InceptionV3(
    input_shape=(299, 299, 3),
    include_top=False,
    weights='imagenet'
)

# Freeze the base model layers
base_model.trainable = False

# Create the complete model
inputs = tf.keras.Input(shape=(299, 299, 3))

# Data augmentation
data_augmentation = tf.keras.Sequential([
    layers.RandomFlip("horizontal"),
    layers.RandomRotation(0.2),
    layers.RandomZoom(0.2),
])

x = data_augmentation(inputs)
x = preprocess_input(x)
x = base_model(x, training=False)

# Default classification head
x = layers.GlobalAveragePooling2D()(x)
x = layers.Dropout(0.2)(x)
outputs = layers.Dense(5, activation='softmax')(x)

# Build the model
model = tf.keras.Model(inputs, outputs)

# Model summary
print(f"Total layers: {len(model.layers)}")
print(f"Trainable layers: {sum([layer.trainable for layer in model.layers])}")
model.summary()
# ============================
# TRAINING
# ============================
model.compile(
    optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
    loss="categorical_crossentropy",
    metrics=["accuracy"],
)

history = model.fit(train_ds, validation_data=val_ds, epochs=EPOCHS)

model.save("layernaut_model.keras")
print("Saved model to layernaut_model.keras")
