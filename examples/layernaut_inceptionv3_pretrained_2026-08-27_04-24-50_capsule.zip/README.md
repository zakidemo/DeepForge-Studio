# Reproducibility capsule

Experiment specification and everything needed to re-execute it.

| File | Purpose |
|---|---|
| `train.py` | Training script, seeded |
| `notebook.ipynb` | The same pipeline as a Colab notebook |
| `config.json` | Full specification; re-imports into Layernaut Studio |
| `requirements.txt` | Library versions the code was generated against |
| `ENVIRONMENT.md` | What is pinned, and what cannot be |

## Reproduce

    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    # edit the DATA section of train.py to point at your dataset
    python train.py

`train.py` writes `environment_lock.txt` recording the environment it actually
ran in. Keep it alongside your results.

## Specification

- Tool version: 2.3.0
- Schema version: 2
- Exported: 2026-08-27T03:24:50.133Z
- Model: inceptionv3 (pretrained)
- Seed: 42
